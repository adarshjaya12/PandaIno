extern long RAW_OFFSET;
extern int DST_OFFSET;