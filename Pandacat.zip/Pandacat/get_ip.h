#ifndef _GET_IP_H_
#define _GET_IP_H_

void get_ip();
void get_offset();

#endif