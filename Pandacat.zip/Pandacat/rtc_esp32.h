#ifndef _RTC_ESP32_H_
#define _RTC_ESP32_H_

void print_local_time();
void get_rtc_time();

#endif