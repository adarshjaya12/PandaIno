#ifndef _BLE_ADV_H_
#define _BLE_ADV_H_

void ble_loop();
void ble_setup();
//void ble_tx();

#endif